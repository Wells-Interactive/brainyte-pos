const tableGrid = document.getElementById('tableGrid');
const selectedTableName = document.getElementById('selectedTableName');
const menuList = document.getElementById('menuList');
const orderSummary = document.getElementById('orderSummary');
const subtotalAmount = document.getElementById('subtotalAmount');
const vatAmount = document.getElementById('vatAmount');
const grandTotalAmount = document.getElementById('grandTotalAmount');
const sendOrderButton = document.getElementById('sendOrderButton');
const markPaidButton = document.getElementById('markPaidButton');
const orderFeedback = document.getElementById('orderFeedback');
const instructionsInput = document.getElementById('instructions');
const paymentMethodSelect = document.getElementById('paymentMethod');
const confirmationDialog = document.getElementById('orderConfirmation');
const confirmationDetails = document.getElementById('confirmationDetails');
const cancelConfirmationButton = document.getElementById('cancelConfirmation');
const confirmOrderButton = document.getElementById('confirmOrderButton');
const tabs = Array.from(document.querySelectorAll('.tab-button'));

let selectedTable = null;
let orderItems = [];
let currentMenuItems = [];
let currentCategory = 'water';

// Dynamic VAT rate - loaded from settings on init
let VAT_RATE = 0.00;

const categoryLabels = {
    'beer': 'Beer',
    'malt': 'Malt',
    'soft-drinks': 'Soft Drinks',
    'water': 'Water',
    'energy-drinks': 'Energy Drinks',
    'juice': 'Juice',
    'spirits': 'Spirits',
    'ready-to-drink': 'Ready To Drink',
    'rice': 'Rice',
    'pepper-soup': 'Pepper Soup',
    'grills': 'Grills',
    'soups': 'Soups',
    'swallow': 'Swallow',
    'extras': 'Extras',
    'cigarettes': 'Cigarettes',
};

function formatCurrency(value) {
    return new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: 'NGN',
        minimumFractionDigits: 2,
    }).format(value);
}

async function fetchTables() {
    const response = await fetch('/API/Status/index.php');
    const data = await response.json();
    // Support both v1 format (data.data.tables) and legacy format (data.tables)
    const tables = data?.data?.tables ?? data?.tables ?? [];
    tableGrid.innerHTML = tables
        .map((table) => `
            <button type="button" class="table-card status-${table.status || 'available'}" data-id="${table.id}" data-name="${table.name}">
                <strong>${table.name}</strong>
                <span class="status">${table.status || 'available'}</span>
            </button>`)
        .join('');

    tableGrid.querySelectorAll('.table-card').forEach((button) => {
        button.addEventListener('click', () => {
            const tableId = Number(button.dataset.id);
            const tableName = button.dataset.name;
            selectTable(tableId, tableName);
        });
    });
}

function selectTable(tableId, tableName) {
    selectedTable = tableId;
    selectedTableName.textContent = `Selected table: ${tableName}`;
    tableGrid.querySelectorAll('.table-card').forEach((button) => {
        button.classList.toggle('selected', Number(button.dataset.id) === selectedTable);
    });
    updateTotals();
}

async function fetchMenu(category = 'water') {
    currentCategory = category;
    menuList.innerHTML = '<div class="menu-message">Loading menu...</div>';

    try {
        const response = await fetch(`/API/Menu/index.php?category=${encodeURIComponent(category)}`);
        const data = await response.json();
        const items = Array.isArray(data.items) && data.items.length > 0 ? data.items : [];

        if (items.length === 0) {
            currentMenuItems = [];
            menuList.innerHTML = '<div class="menu-message">No menu items are available for this category.</div>';
            return;
        }

        currentMenuItems = items;
        menuList.innerHTML = items
            .map((item) => {
                const existing = orderItems.find((entry) => entry.menu_item_id === item.id);
                const quantity = existing ? existing.quantity : 0;
                const isUnavailable = item.available === 0;
                return `
                <article class="menu-card ${quantity > 0 ? 'selected' : ''} ${isUnavailable ? 'unavailable' : ''}" data-id="${item.id}" data-name="${item.name}" data-price="${item.price}" data-category="${item.category}" data-available="${item.available}">
                    <div class="menu-card-header">
                        <div>
                            <h3>${item.name} ${isUnavailable ? '<span style="color:var(--danger);font-size:0.8rem;">(Out of Stock)</span>' : ''}</h3>
                            <p>${item.description}</p>
                        </div>
                        <div class="item-meta">
                            <span>${categoryLabels[item.category] || item.category}</span>
                            <span>${formatCurrency(Number(item.price))}</span>
                        </div>
                    <div class="menu-card-footer">
                        <div class="quantity-display">Qty: <strong class="item-count">${quantity}</strong></div>
                        <div class="card-actions">
                            ${isUnavailable ? '<span style="color:var(--danger);font-size:0.85rem;">Unavailable</span>' : `
                            <button type="button" class="control-button" data-action="decrease">-</button>
                            <button type="button" class="control-button" data-action="increase">+</button>`}
                        </div>
                        <div class="card-click-tip">${isUnavailable ? 'Out of stock' : 'Tap card to add'}</div>
                </article>`;
            })
            .join('');

        updateMenuCardState();
    } catch (error) {
        console.error('Unable to load menu items', error);
        menuList.innerHTML = '<div class="menu-message">Unable to load menu items right now.</div>';
    }
}

function handleMenuClick(event) {
    const card = event.target.closest('.menu-card');
    if (!card) {
        return;
    }

    // Check if item is unavailable
    const isAvailable = parseInt(card.dataset.available || '1') === 1;
    if (!isAvailable) {
        return;
    }

    const actionButton = event.target.closest('button[data-action]');
    const action = actionButton ? actionButton.dataset.action : undefined;
    const item = {
        id: Number(card.dataset.id),
        name: card.dataset.name,
        price: Number(card.dataset.price),
        category: card.dataset.category,
        available: Number(card.dataset.available),
    };

    if (action === 'increase') {
        addItem(item, 1);
        return;
    }

    if (action === 'decrease') {
        addItem(item, -1);
        return;
    }

    addItem(item, 1);
}

function handleSummaryClick(event) {
    const action = event.target.dataset.action;
    if (!action) {
        return;
    }

    const block = event.target.closest('.summary-item-block');
    if (!block) {
        return;
    }

    const itemId = Number(block.dataset.id);
    const item = orderItems.find((entry) => entry.menu_item_id === itemId);
    if (!item) {
        return;
    }

    if (action === 'increase') {
        addItem(item, 1);
    }

    if (action === 'decrease') {
        addItem(item, -1);
    }
}

function addItem(item, delta) {
    if (!item || !Number.isInteger(delta) || delta === 0) {
        return;
    }

    const menuItemId = Number(item.menu_item_id ?? item.id);
    if (menuItemId <= 0) {
        return;
    }

    const unitPrice = Number(item.unit_price ?? item.price ?? 0);
    const name = item.name ?? item.menu_item_name ?? '';
    const category = item.category ?? '';

    const existing = orderItems.find((row) => row.menu_item_id === menuItemId);
    if (existing) {
        existing.quantity = Math.max(0, existing.quantity + delta);
        if (existing.quantity === 0) {
            orderItems = orderItems.filter((row) => row.menu_item_id !== menuItemId);
        }
    } else if (delta > 0) {
        orderItems.push({
            menu_item_id: menuItemId,
            name,
            unit_price: unitPrice,
            quantity: 1,
            category,
            instructions: '', // per-item instructions
        });
    }

    refreshOrderState();
}

function refreshOrderState() {
    updateTotals();
    renderOrderSummary();
    updateMenuCardState();
    updateSendButtonState();
}

function updateSendButtonState() {
    const enabled = orderItems.length > 0 && selectedTable !== null;
    sendOrderButton.disabled = !enabled;
    sendOrderButton.classList.toggle('active', enabled);
    if (markPaidButton) {
        markPaidButton.disabled = selectedTable === null;
    }
}

function updateMenuCardState() {
    menuList.querySelectorAll('.menu-card').forEach((card) => {
        const itemId = Number(card.dataset.id);
        const entry = orderItems.find((row) => row.menu_item_id === itemId);
        const quantity = entry ? entry.quantity : 0;
        card.classList.toggle('selected', quantity > 0);
        const countElement = card.querySelector('.item-count');
        if (countElement) {
            countElement.textContent = quantity;
        }
    });
}

function renderOrderSummary() {
    if (orderItems.length === 0) {
        orderSummary.innerHTML = '<div class="order-empty">No items selected yet.</div>';
        return;
    }

    orderSummary.innerHTML = `
        <div class="summary-header">
            <span>Item</span>
            <span>Qty</span>
            <span>Unit Price</span>
            <span>Subtotal</span>
            <span>Adjust</span>
        </div>
        ${orderItems
            .map((item, index) => `
            <div class="summary-item-block" data-id="${item.menu_item_id}">
                <div class="summary-row">
                    <span class="summary-name">${item.name}</span>
                    <span>${item.quantity}</span>
                    <span>${formatCurrency(item.unit_price)}</span>
                    <span>${formatCurrency(item.unit_price * item.quantity)}</span>
                    <span class="summary-controls">
                        <button type="button" data-action="decrease">-</button>
                        <button type="button" data-action="increase">+</button>
                    </span>
                </div>
                <div class="summary-instructions">
                    <input type="text" class="item-instructions-input" data-item-id="${item.menu_item_id}" placeholder="Item instructions (e.g. No pepper)" value="${item.instructions || ''}" />
                </div>
            </div>`)
            .join('')}
    `;

    // Attach instructions change handlers
    document.querySelectorAll('.item-instructions-input').forEach((input) => {
        input.addEventListener('input', (e) => {
            const itemId = Number(e.target.dataset.itemId);
            const entry = orderItems.find((row) => row.menu_item_id === itemId);
            if (entry) {
                entry.instructions = e.target.value;
            }
        });
    });
}

function updateTotals() {
    const subtotal = orderItems.reduce((sum, item) => sum + item.quantity * item.unit_price, 0);
    const vat = Number((subtotal * VAT_RATE).toFixed(2));
    const grandTotal = Number((subtotal + vat).toFixed(2));

    subtotalAmount.textContent = formatCurrency(subtotal);
    vatAmount.textContent = formatCurrency(vat);
    grandTotalAmount.textContent = formatCurrency(grandTotal);
    updateSendButtonState();
}

function showConfirmation() {
    if (orderItems.length === 0 || selectedTable === null) {
        return;
    }

    const instructionText = instructionsInput.value.trim() || 'None';
    const paymentMethod = (paymentMethodSelect?.value || 'pending').toLowerCase();
    const rows = orderItems
        .map(
            (item) => `<div class="confirmation-row"><span>${item.name} x${item.quantity}${item.instructions ? `<br/><small style="color:var(--muted);font-size:0.85rem;">Note: ${item.instructions}</small>` : ''}</span><strong>${formatCurrency(item.unit_price * item.quantity)}</strong></div>`
        )
        .join('');

    const subtotal = orderItems.reduce((sum, item) => sum + item.quantity * item.unit_price, 0);
    const vat = Number((subtotal * VAT_RATE).toFixed(2));
    const grandTotal = Number((subtotal + vat).toFixed(2));

    confirmationDetails.innerHTML = `
        <div class="confirmation-row"><span>Table:</span><strong>Table ${selectedTable}</strong></div>
        <div class="confirmation-row"><span>Payment Method:</span><strong>${paymentMethod}</strong></div>
        <div class="confirmation-row"><span>Instructions:</span><strong>${instructionText}</strong></div>
        ${rows}
        <div class="confirmation-row"><span>Subtotal:</span><strong>${formatCurrency(subtotal)}</strong></div>
        <div class="confirmation-row"><span>VAT (0.0%):</span><strong>${formatCurrency(vat)}</strong></div>
        <div class="confirmation-row"><span>Grand Total:</span><strong>${formatCurrency(grandTotal)}</strong></div>
    `;
    confirmationDialog.classList.remove('hidden');
}

function closeConfirmation() {
    confirmationDialog.classList.add('hidden');
}

function buildDirectDocketHtml(items, location, tableId, waiterName, instructions) {
    const now = new Date().toLocaleString();
    const locationLabel = location === 'kitchen' ? 'KITCHEN' : 'BAR';
    let itemsHtml = '';
    let total = 0;
    items.forEach((item) => {
        const itemTotal = item.quantity * item.unit_price;
        total += itemTotal;
        itemsHtml += `<tr><td>${item.item_name}</td><td class="qty">${item.quantity}</td><td class="price">${formatCurrency(itemTotal)}</td></tr>`;
    });

    return `
    <html>
    <head>
        <meta charset="UTF-8">
        <title>${locationLabel} Docket</title>
        <style>
            @page { margin: 0; size: 80mm auto; }
            body { font-family: 'Courier New', monospace; font-size: 12px; margin: 0; padding: 8px; width: 72mm; }
            h2 { text-align: center; font-size: 16px; margin: 4px 0; }
            h3 { text-align: center; font-size: 14px; margin: 4px 0; }
            .divider { border-top: 1px dashed #000; margin: 6px 0; }
            .row { display: flex; justify-content: space-between; font-size: 12px; padding: 2px 0; }
            .footer { text-align: center; font-size: 10px; margin-top: 8px; }
            .bold { font-weight: bold; }
            table { width: 100%; border-collapse: collapse; }
            td { padding: 2px 0; }
            .qty { text-align: center; }
            .price { text-align: right; }
        </style>
    </head>
    <body>
        <h2>${locationLabel} DOCKET</h2>
        <div class="divider"></div>
        <div class="row"><span>Table:</span><span class="bold">${tableId}</span></div>
        <div class="row"><span>Waiter:</span><span class="bold">${waiterName}</span></div>
        <div class="row"><span>Time:</span><span>${now}</span></div>
        <div class="divider"></div>
        <table>
            <tr><td><strong>Item</strong></td><td class="qty"><strong>Qty</strong></td><td class="price"><strong>Amount</strong></td></tr>
            ${itemsHtml}
        </table>
        <div class="divider"></div>
        <div class="row"><span>Total:</span><span class="bold">${formatCurrency(total)}</span></div>
        ${instructions ? `<div class="divider"></div><p><strong>Instructions:</strong> ${instructions}</p>` : ''}
        <div class="divider"></div>
        <div class="footer">
            <p>Powered by Brainyte</p>
            <p>Thank you!</p>
        </div>
        <script>
            window.onload = function() { window.print(); setTimeout(function() { window.close(); }, 500); }
        <\/script>
    </body>
    </html>`;
}

async function submitOrder() {
    if (orderItems.length === 0 || selectedTable === null) {
        return;
    }

    const payload = {
        table_id: selectedTable,
        instructions: instructionsInput.value.trim(),
        payment_method: (paymentMethodSelect?.value || 'pending').toLowerCase(),
        items: orderItems.map((item) => ({
            menu_item_id: item.menu_item_id,
            quantity: item.quantity,
            instructions: item.instructions || null,
        })),
    };

    try {
        const response = await fetch('/API/Orders/index.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) {
            orderFeedback.textContent = data.error || 'Unable to send order';
            closeConfirmation();
            return;
        }

        orderFeedback.textContent = 'Order sent successfully!';

        // Handle direct printing
        if (data.direct_print) {
            const waiterName = data.kitchen_items?.[0]?.waiter_name || '';
            const tableId = data.table_id || selectedTable;
            const instructions = data.instructions || '';

            // Print kitchen docket
            if (data.kitchen_items && data.kitchen_items.length > 0) {
                const kitchenHtml = buildDirectDocketHtml(data.kitchen_items, 'kitchen', tableId, waiterName, instructions);
                const kitchenWindow = window.open('', '_blank', 'width=300,height=600,menubar=no,toolbar=no');
                if (kitchenWindow) {
                    kitchenWindow.document.write(kitchenHtml);
                    kitchenWindow.document.close();
                }
            }

            // Print bar docket
            if (data.bar_items && data.bar_items.length > 0) {
                const barHtml = buildDirectDocketHtml(data.bar_items, 'bar', tableId, waiterName, instructions);
                const barWindow = window.open('', '_blank', 'width=300,height=600,menubar=no,toolbar=no');
                if (barWindow) {
                    barWindow.document.write(barHtml);
                    barWindow.document.close();
                }
            }
        }

        orderItems = [];
        instructionsInput.value = '';
        await fetchTables();
        updateTotals();
        renderOrderSummary();
        updateMenuCardState();
        closeConfirmation();
    } catch (error) {
        orderFeedback.textContent = 'Network issue. Please try again.';
        closeConfirmation();
    }
}

async function markTablePaid() {
    if (selectedTable === null) {
        return;
    }

    try {
        const response = await fetch('/API/Status/index.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'mark_paid',
                table_id: selectedTable,
                payment_method: (paymentMethodSelect?.value || 'pending').toLowerCase(),
            }),
        });
        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'Unable to mark table as paid');
        }
        orderFeedback.textContent = 'Table marked as paid.';
        await fetchTables();
        orderItems = [];
        instructionsInput.value = '';
        updateTotals();
        renderOrderSummary();
        updateMenuCardState();
    } catch (error) {
        orderFeedback.textContent = error.message || 'Unable to mark table as paid.';
    }
}

function attachEvents() {
    sendOrderButton.addEventListener('click', showConfirmation);
    markPaidButton?.addEventListener('click', markTablePaid);
    confirmationDialog.addEventListener('click', (event) => {
        if (event.target === confirmationDialog) {
            closeConfirmation();
        }
    });
    cancelConfirmationButton.addEventListener('click', closeConfirmation);
    confirmOrderButton.addEventListener('click', submitOrder);
    menuList.addEventListener('click', handleMenuClick);
    orderSummary.addEventListener('click', handleSummaryClick);
    tabs.forEach((tab) => {
        tab.addEventListener('click', () => {
            tabs.forEach((button) => button.classList.remove('active'));
            tab.classList.add('active');
            currentCategory = tab.dataset.category;
            fetchMenu(currentCategory);
        });
    });
}

(async function init() {
    // Load VAT from settings dynamically
    try {
        const settingsResp = await fetch('/API/Settings/index.php');
        const settingsResult = await settingsResp.json();
        const settingsData = settingsResult.data || settingsResult;
        if (settingsData.settings && settingsData.settings.vat_rate) {
            VAT_RATE = parseFloat(settingsData.settings.vat_rate) / 100;
        } else if (settingsData.vat_rate) {
            VAT_RATE = parseFloat(settingsData.vat_rate) / 100;
        }
    } catch (e) {
        console.warn('Could not load VAT rate, using default 0%');
    }

    await fetchTables();
    await fetchMenu(currentCategory);
    updateTotals();
    renderOrderSummary();
    attachEvents();
})();
