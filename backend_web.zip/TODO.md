# Setup & Backend Gating Fix - Task Checklist

## Goal
Fix the Setup wizard so installation works end-to-end (including writing `includes/db.php`),
gate the backend behind setup completion, keep `schema.sql` in sync with `db.php`/`db.example.php`,
and ensure table selection always displays as a Grid on all devices.

## Steps

### 1. includes/utils.php
- [x] Add `db_config_exists()` helper
- [ ] Add `setup_required()` helper
- [ ] Add `require_setup_or_redirect()` helper
- [ ] Harden `init_timezone()` to not call undefined `get_db()`

### 2. index.php
- [ ] Gate backend behind setup completion
- [ ] Redirect to /Setup/index.php when db.php missing / DB fails / no admin exists
- [ ] Backend renders only when setup is complete

### 3. Setup/index.php
- [ ] Remove hard requirement of includes/db.php
- [ ] Add Database Configuration form (host/name/user/pass) when db missing/connection fails
- [ ] Write includes/db.php from db.example.php template on successful test
- [ ] Preserve existing wizard steps (Database Check → Admin Account → Complete)

### 4. API/Setup/index.php
- [ ] Handle missing db.php gracefully (GET: setup_required true, POST: clear error)

### 5. includes/db.php
- [ ] Update ensure_database_schema() to match db.example.php / schema.sql
- [ ] Preserve real DB credentials

### 6. Backend pages (Waiter, Kitchen, Bar, Manager, Admin/Menu)
- [ ] Add require_setup_or_redirect() to each protected page

### 7. assets/css/style.css
- [ ] Harden .table-grid for responsive grid layout on all devices

### 8. Verification
- [ ] Confirm schema.sql matches db.php/db.example.php
- [ ] Confirm setup flow works
- [ ] Confirm table selection grid renders on all devices

