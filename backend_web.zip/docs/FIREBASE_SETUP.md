# Firebase Cloud Messaging setup

1. Create or select the restaurant Firebase project, enable Cloud Messaging, and enable the FCM Registration API.
2. Copy `assets/js/firebase-config.example.js` to the ignored deployment file `assets/js/firebase-config.js`; enter the public web configuration and Web Push VAPID key.
3. Serve the POS over HTTPS. Browser push and service workers require HTTPS.
4. Keep the Firebase service-account JSON only on the server and set `FIREBASE_SERVICE_ACCOUNT_PATH` to its absolute, readable path in PHP-FPM/Apache. The backend uses the FCM HTTP v1 API and short-lived OAuth tokens.

The POS stores each signed-in browser token in `push_subscriptions`. Existing database notifications remain the source of truth; a failed or unconfigured FCM transport never drops an order or notification.
