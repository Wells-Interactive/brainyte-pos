<?php
declare(strict_types=1);

namespace App;

use PDO;
use Throwable;

/**
 * Database Migration Manager
 *
 * Executes versioned SQL migrations stored in:
 * database/migrations/
 *
 * Migration files must be named:
 * 001_description.sql
 * 002_description.sql
 * etc.
 *
 * Transaction control is handled by this class.
 * Migration SQL files must NOT contain:
 * START TRANSACTION;
 * BEGIN;
 * COMMIT;
 * ROLLBACK;
 */
class Migration
{
    private PDO $pdo;

    private const MIGRATIONS_TABLE = 'schema_migrations';

    private const MIGRATIONS_DIR = __DIR__ . '/../../database/migrations';

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Ensure the migration tracking table exists.
     */
    private function ensureTrackingTable(): void
    {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS `" . self::MIGRATIONS_TABLE . "` (
                id INT AUTO_INCREMENT PRIMARY KEY,
                migration VARCHAR(255) NOT NULL UNIQUE,
                batch INT NOT NULL DEFAULT 1,
                executed_at DATETIME NOT NULL,
                INDEX idx_migration (migration)
            ) ENGINE=InnoDB
            DEFAULT CHARSET=utf8mb4
            COLLATE=utf8mb4_unicode_ci
        ");
    }

    /**
     * Get migrations already executed.
     */
    public function getExecutedMigrations(): array
    {
        $this->ensureTrackingTable();

        $stmt = $this->pdo->query(
            "SELECT migration
             FROM `" . self::MIGRATIONS_TABLE . "`
             ORDER BY migration"
        );

        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Get all migration files.
     */
    public function getAvailableMigrations(): array
    {
        $dir = self::MIGRATIONS_DIR;

        if (!is_dir($dir)) {
            return [];
        }

        $files = glob($dir . '/*.sql');

        if ($files === false) {
            return [];
        }

        sort($files, SORT_STRING);

        return $files;
    }

   /**
 * Run all pending migrations.
 *
 * Migration files are executed as complete SQL scripts.
 * Transaction control is handled by the migration file itself.
 *
 * @return array List of executed migrations with status
 */
public function migrate(): array
{
    $executed = $this->getExecutedMigrations();
    $available = $this->getAvailableMigrations();
    $results = [];
    $batch = $this->getNextBatch();

    foreach ($available as $filepath) {
        $filename = basename($filepath);

        if (in_array($filename, $executed, true)) {
            continue;
        }

        $sql = file_get_contents($filepath);

        if ($sql === false || trim($sql) === '') {
            $results[] = [
                'migration' => $filename,
                'status' => 'skipped',
                'reason' => 'Empty or unreadable file',
            ];
            continue;
        }

        try {
            /*
             * Do NOT call beginTransaction() here.
             *
             * Migration files may contain:
             *
             * START TRANSACTION;
             * ...
             * COMMIT;
             *
             * Also, MySQL DDL statements such as CREATE TABLE
             * and ALTER TABLE can implicitly commit transactions.
             */

            $this->executeSqlScript($sql);

            // Record migration only after the SQL script succeeds.
            $stmt = $this->pdo->prepare(
                "INSERT INTO `" . self::MIGRATIONS_TABLE . "`
                (migration, batch, executed_at)
                VALUES (:migration, :batch, :executed_at)"
            );

            $stmt->execute([
                ':migration' => $filename,
                ':batch' => $batch,
                ':executed_at' => date('Y-m-d H:i:s'),
            ]);

            $results[] = [
                'migration' => $filename,
                'status' => 'executed',
                'batch' => $batch,
            ];

        } catch (Throwable $e) {
            /*
             * Do not blindly call rollBack().
             *
             * The migration itself may already have committed,
             * or MySQL may have implicitly committed a transaction.
             */
            if ($this->pdo->inTransaction()) {
                try {
                    $this->pdo->rollBack();
                } catch (Throwable $rollbackError) {
                    // Ignore rollback errors.
                }
            }

            $results[] = [
                'migration' => $filename,
                'status' => 'failed',
                'error' => $e->getMessage(),
            ];

            /*
             * Stop here. Later migrations may depend on this one.
             */
            break;
        }
    }

    return $results;
}

    /**
     * Check whether every migration has executed.
     */
    public function isFullyMigrated(): bool
    {
        $executed = $this->getExecutedMigrations();
        $available = $this->getAvailableMigrations();

        return count($executed) >= count($available);
    }

    /**
     * Create a new migration file.
     */
    public static function createMigration(string $description): string
    {
        $dir = self::MIGRATIONS_DIR;

        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $timestamp = date('Ymd_His');

        $safeDescription = preg_replace(
            '/[^a-zA-Z0-9_]/',
            '_',
            $description
        );

        $filename = $timestamp . '_' . $safeDescription . '.sql';

        $filepath = $dir . '/' . $filename;

        $template = <<<SQL
-- Migration: {$filename}
-- Description: {$description}
-- Generated: %s

-- Write migration SQL here.

SQL;

        file_put_contents(
            $filepath,
            sprintf($template, date('Y-m-d H:i:s'))
        );

        return $filepath;
    }

    /**
     * Get next migration batch.
     */
    private function getNextBatch(): int
    {
        $stmt = $this->pdo->query(
            "SELECT COALESCE(MAX(batch), 0) + 1
             FROM `" . self::MIGRATIONS_TABLE . "`"
        );

        return (int)$stmt->fetchColumn();
    }

/**
 * Execute a complete SQL migration script.
 *
 * MySQL supports multi-statements through PDO::exec().
 * We intentionally execute the migration as one script instead
 * of splitting it on semicolons.
 */
private function executeSqlScript(string $sql): void
{
    $sql = trim($sql);

    if ($sql === '') {
        return;
    }

    /*
     * Remove UTF-8 BOM if present.
     */
    $sql = preg_replace('/^\xEF\xBB\xBF/', '', $sql);

    /*
     * PDO::exec() can execute multiple MySQL statements when
     * MYSQL_ATTR_MULTI_STATEMENTS is enabled.
     *
     * The migration connection uses the same PDO connection,
     * so enable it explicitly for this execution.
     */
    $this->pdo->setAttribute(PDO::MYSQL_ATTR_MULTI_STATEMENTS, true);

    $this->pdo->exec($sql);

    /*
     * Consume any remaining result sets produced by a
     * multi-statement script.
     *
     * This is important because otherwise MySQL can report:
     *
     * SQLSTATE[HY000]: General error: 2014
     * Cannot execute queries while other unbuffered queries
     * are active.
     */
    while ($this->pdo->nextRowset()) {
        // Consume remaining result sets.
    }

    /*
     * Restore normal behaviour.
     */
    $this->pdo->setAttribute(PDO::MYSQL_ATTR_MULTI_STATEMENTS, false);
}


    /**
     * Split SQL into statements.
     *
     * Handles:
     * - single quotes
     * - double quotes
     * - backticks
     * - -- comments
     * - /* comments *\/
     */
    private function splitSql(string $sql): array
    {
        $statements = [];

        $current = '';
        $length = strlen($sql);

        $inSingleQuote = false;
        $inDoubleQuote = false;
        $inBacktick = false;
        $inLineComment = false;
        $inBlockComment = false;

        for ($i = 0; $i < $length; $i++) {
            $char = $sql[$i];
            $next = $i + 1 < $length ? $sql[$i + 1] : '';

            /*
             * Line comment
             */
            if ($inLineComment) {
                if ($char === "\n") {
                    $inLineComment = false;
                    $current .= $char;
                }

                continue;
            }

            /*
             * Block comment
             */
            if ($inBlockComment) {
                if ($char === '*' && $next === '/') {
                    $inBlockComment = false;
                    $i++;
                }

                continue;
            }

            /*
             * Start line comment
             */
            if (
                !$inSingleQuote &&
                !$inDoubleQuote &&
                !$inBacktick &&
                $char === '-' &&
                $next === '-'
            ) {
                $inLineComment = true;
                $i++;
                continue;
            }

            /*
             * Start block comment
             */
            if (
                !$inSingleQuote &&
                !$inDoubleQuote &&
                !$inBacktick &&
                $char === '/' &&
                $next === '*'
            ) {
                $inBlockComment = true;
                $i++;
                continue;
            }

            /*
             * Single quotes
             */
            if (!$inDoubleQuote && !$inBacktick && $char === "'") {
                if ($inSingleQuote && $next === "'") {
                    $current .= "''";
                    $i++;
                    continue;
                }

                $inSingleQuote = !$inSingleQuote;
                $current .= $char;
                continue;
            }

            /*
             * Double quotes
             */
            if (!$inSingleQuote && !$inBacktick && $char === '"') {
                $inDoubleQuote = !$inDoubleQuote;
                $current .= $char;
                continue;
            }

            /*
             * Backticks
             */
            if (!$inSingleQuote && !$inDoubleQuote && $char === '`') {
                $inBacktick = !$inBacktick;
                $current .= $char;
                continue;
            }

            /*
             * Statement separator
             */
            if (
                $char === ';' &&
                !$inSingleQuote &&
                !$inDoubleQuote &&
                !$inBacktick
            ) {
                if (trim($current) !== '') {
                    $statements[] = trim($current);
                }

                $current = '';

                continue;
            }

            $current .= $char;
        }

        if (trim($current) !== '') {
            $statements[] = trim($current);
        }

        return $statements;
    }

    /**
     * Get migration status.
     */
    public function getStatus(): array
    {
        $executed = $this->getExecutedMigrations();
        $available = $this->getAvailableMigrations();

        $status = [];

        foreach ($available as $filepath) {
            $filename = basename($filepath);

            $status[] = [
                'migration' => $filename,
                'executed' => in_array(
                    $filename,
                    $executed,
                    true
                ),
            ];
        }

        return $status;
    }
}
