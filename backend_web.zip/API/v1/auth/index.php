<?php
declare(strict_types=1);
/**
 * API v1 - Authentication
 *
 * POST /API/v1/auth/index.php - Login
 *   Body: { email, password, device_name?: string }
 *   Response: { access_token, refresh_token, token_type, expires_in, refresh_expires_in, user }
 *
 * This is the stable public API for the Flutter application.
 */

require_once __DIR__ . '/../../../includes/bootstrap.php';
require_once __DIR__ . '/../../../includes/db.php';
require_once __DIR__ . '/../../../includes/utils.php';

use App\Auth;
use App\AuditLog;
use App\RateLimiter;

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

try {
    $body = get_json_body();
} catch (JsonException $e) {
    json_response(['error' => 'Invalid JSON body'], 400);
}

$email = trim((string)($body['email'] ?? ''));
$password = (string)($body['password'] ?? '');
$deviceName = trim((string)($body['device_name'] ?? ''));

if ($email === '' || $password === '') {
    json_response(['error' => 'Email and password are required'], 400);
}

$pdo = get_db();
$auth = new Auth($pdo);
$auditLog = new AuditLog($pdo);
$rateLimiter = new RateLimiter($pdo);

// Rate limiting
$clientIp = RateLimiter::getClientIp();
$rateCheck = $rateLimiter->checkLogin($clientIp . '|' . $email);
if (!$rateCheck['allowed']) {
    $auditLog->log(null, 'login_throttled', 'auth', null, "Login throttled for {$email} from {$clientIp}");
    http_response_code(429);
    echo json_encode(['error' => 'Too many login attempts. Please try again later.']);
    exit;
}

// Authenticate
$user = $auth->login($email, $password);

if (empty($user)) {
    $rateLimiter->recordLoginAttempt($clientIp . '|' . $email, false);
    $auditLog->log(null, 'login_failed', 'auth', null, "Failed v1 login attempt for {$email} from {$clientIp}");
    json_response(['error' => 'Invalid credentials'], 401);
}

// Home-delivery customers must complete the email OTP verification before login.
if ($user['role'] === 'customer') {
    $verification = $pdo->prepare('SELECT email_verified_at FROM customer_profiles WHERE user_id = :user_id LIMIT 1');
    $verification->execute([':user_id' => $user['id']]);
    $profile = $verification->fetch();
    if (!$profile || $profile['email_verified_at'] === null) {
        json_response(['error' => 'Verify your email before signing in'], 403);
    }
}

// Record successful login
$rateLimiter->recordLoginAttempt($clientIp . '|' . $email, true);
$auditLog->login($user['id'], true, 'v1_api');

// Generate token pair for Flutter
$tokens = $auth->generateTokenPair($user['id'], $deviceName);

json_response([
    'success' => true,
    'data' => [
        'access_token' => $tokens['access_token'],
        'refresh_token' => $tokens['refresh_token'],
        'token_type' => 'Bearer',
        'expires_in' => $tokens['expires_in'],
        'refresh_expires_in' => $tokens['refresh_expires_in'],
        'user' => [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
        ],
    ],
    'error' => null,
    'meta' => null,
]);
